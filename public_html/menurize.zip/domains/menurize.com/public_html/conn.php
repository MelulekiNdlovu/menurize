<?php
    $dbhost = 'localhost';
    $dbuser = 'menumel_chows';
    $dbpass = '0szX8hCIpT';
    $dbname = 'menumel_chows';
?>