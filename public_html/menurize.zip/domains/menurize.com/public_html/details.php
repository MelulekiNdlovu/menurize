<?php
    session_start();

    require 'conn.php';

    $restName = "";
    $address = "";
    $city = "";

    $sess_id = $_SESSION["sess_id"];
    $sel = "";

    //Create database connection
    $dblink = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

    //Check connection was successful
    if ($dblink->connect_errno) {
        printf("Failed to connect to database");
        exit();
    }

    if ( isset($_POST["update"]) )  {

        $restName = $_POST["restName"];
        $address = $_POST["address"];
        $city = $_POST["city"];
        $curr = $_POST["curr"];

        //updating restaurant name
        if($_POST["restName"] != "" ){
            
            $sql = "UPDATE restaurants SET name='$restName' WHERE id=$sess_id ";
            $result = $dblink->query($sql);
            if ($dblink->query($sql) === TRUE) {
                echo "Restaurant Name updated successfully";
            } else {
                echo "Error updating record: " . $dblink->error;
            }
            $_SESSION["nameMsg"] = $_POST["restName"]." has been UPDATED.";

            
        }

        //updating address
        if($_POST["address"] != "" ){
            
            $sql = "UPDATE restaurants SET address='$address' WHERE id=$sess_id ";
            $result = $dblink->query($sql);
            if ($dblink->query($sql) === TRUE) {
                echo "Address updated successfully";
            } else {
                echo "Error updating record: " . $dblink->error;
            }
            $_SESSION["priceMsg"] = "Address has been UPDATED to: $".$_POST["address"]."<br>";

        }

        //updating the city
        if($_POST["city"] != "" ){
            
            $sql = "UPDATE restaurants SET city='$city' WHERE id=$sess_id ";
            $result = $dblink->query($sql);
            if ($dblink->query($sql) === TRUE) {
                echo "City updated successfully";
            } else {
                echo "Error updating record: " . $dblink->error;
            }
            $_SESSION["priceMsg"] = "City has been UPDATED to: $".$_POST["city"]."<br>";

        }


        //updating the currency
        if($_POST["curr"] != "" ){
            
            //update currency
            $sql = "UPDATE restaurants SET curr='$curr' WHERE id=$sess_id ";
            $result = $dblink->query($sql);
            if ($dblink->query($sql) === TRUE) {
                echo "Currency updated successfully";
            } else {
                echo "Error updating record: " . $dblink->error;
            }
            $_SESSION["priceMsg"] = "Currency has been UPDATED to: $".$_POST["curr"]."<br>";

        }


        /*/updating the logo
        if(isset($_POST["logo"])){

            $target_dir = "img/".$sess_id."/";
            $target_file = $target_dir . basename($_FILES['logo']['name']);
          echo $target_file;

            if (file_exists($target_dir)) {
                echo "The file ". $target_dir ." exists";
            } else {
                mkdir($target_dir);
            }
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            // Check if image file is a actual image or fake image
            if(isset($_POST["logo"])) {
                $check = getimagesize($_FILES["logo"]["tmp_name"]);
                if($check !== false) {
                    echo "File is an image - " . $check["mime"] . ".";
                    $uploadOk = 1;
                } else {
                    echo "File is not an image.";
                    $uploadOk = 0;
                }
            }



            // Check file size
            if ($_FILES["logo"]["size"] > 1000000) {
                //1Mb size limit
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }

            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }

            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
                // if everything is ok, try to upload file
            } else {
                if (move_uploaded_file($_FILES["logo"]["tmp_name"], $target_file)) {
                    echo "The file ". htmlspecialchars( basename( $_FILES["logo"]["name"])). " has been uploaded.";
                } else {
                    echo "Sorry, there was an error uploading your file.";
                }
            }

            
            //update logo
            $sql = "UPDATE restaurants SET logo='$target_file' WHERE id=$sess_id ";
            $result = $dblink->query($sql);
            if ($dblink->query($sql) === TRUE) {
                echo "Logo updated successfully";
            } else {
                echo "Error updating record: " . $dblink->error;
            }
            $_SESSION["priceMsg"] = "Logo Updated<br>";

        }*/

    }
    header("Location: admin.php");
?>