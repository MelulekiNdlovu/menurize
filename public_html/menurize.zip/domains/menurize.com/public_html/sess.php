<?php
	session_start();
    if ( isset($_SESSION["username"]) ) {
        echo "<a class=\"nav-link link-light\" href=\"admin.php\">My Menu</a>";
    }else{ echo ""; }
?>